This line chart shows one week of temperature (in degrees Celcius) in cities around the world. The data comes from [Data Canvas - Sense Your City](https://grayarea.org/initiative/data-canvas-sense-your-city/).

<iframe width="560" height="315" src="https://www.youtube.com/embed/xFI-us1moj0?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>